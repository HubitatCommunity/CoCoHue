/*
 * =============================  CoCoHue Contact Sensor (Driver) ===============================
 *
 *  Copyright 2025 Robert Morris
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 * =======================================================================================
 *
 *  Last modified: 2025-10-05
 *
 *  Changelog:
 *  v5.6     - Initial release
 */
 

import groovy.transform.Field
import hubitat.scheduling.AsyncResponse

@Field static final Integer debugAutoDisableMinutes = 30

@Field static final List<Map<String,String>> volumeOptions = [
   ["101": "Hue default [DEFAULT]"],
   ["1": "1%"],
   ["5": "5%"],
   ["10": "10%"],
   ["15": "15%"],
   ["20": "20%"],
   ["25": "25%"],
   ["30": "30%"],
   ["35": "35%"],
   ["40": "40%"],
   ["45": "45%"],
   ["50": "50%"],
   ["55": "55%"],
   ["60": "60%"],
   ["65": "65%"],
   ["70": "70%"],
   ["75": "75%"],
   ["80": "80%"],
   ["85": "85%"],
   ["90": "90%"],
   ["95": "95%"],
   ["100": "100%"]
]

metadata {
   definition(name: "CoCoHue Chime", namespace: "RMoRobert", author: "Robert Morris", importUrl: "https://raw.githubusercontent.com/HubitatCommunity/CoCoHue/master/drivers/cocohue-chime-driver.groovy") {
      capability "Actuator"
      capability "Alarm" // using for "alarm" object in Hue API
      capability "Chime" // using for "chime" object in Hue API
      capability "Tone"  // using for "alert" object in Hue API

      attribute "mute", "enum", ["muted", "unmuted", "unknown"]  // read only, so probably don't want to use any capability
      attribute "networkStatus", "enum", ["online", "offine"]
   }

   preferences {
      input name: "sirenVolume", type: "enum", title: "Alarm (\"Siren\" command) volume", options: volumeOptions, defaultValue: "101", required: false
      input name: "chimeVolume", type: "enum", title: "Chime (\"Play Sound\" command) volume", options: volumeOptions, defaultValue: "101", required: false
      input name: "beepVolume", type: "enum", title: "Tone/alert (\"Beep\" command) volume", options: volumeOptions, defaultValue: "101", required: false
      input name: "logEnable", type: "bool", title: "Enable debug logging", defaultValue: true
      input name: "txtEnable", type: "bool", title: "Enable descriptionText logging", defaultValue: true
   }
}

void installed() {
   log.debug "installed()"
   if (device.currentValue("soundEffects") == null) {
      // Populate initial device data from cache
      List bridgeCacheData = parent.getBridgeCacheV2()?.data ?: []
      Map devCache = bridgeCacheData.find { it.type == "speaker" && it.id == device.deviceNetworkId.split("/").last() }
      if (devCache != null) {
         createEventsFromMapV2(devCache)
         // Also fetch Zigbee connectivity status from other data if available:
         String deviceId = devCache?.owner?.rid
         String zigbeeConnectivityId =  bridgeCacheData.find { it.type == "device" && it.id == deviceId }?.services?.find { it.rtype == "zigbee_connectivity" }?.rid
         String zigbeeConnectivityStatus = bridgeCacheData.find { it.type == "zigbee_connectivity" && it.id == zigbeeConnectivityId }?.get("status")
         if (zigbeeConnectivityStatus) {
            createEventsFromMapV2([type: "zigbee_connectivity", status: zigbeeConnectivityStatus])
         }
      }
   }
   initialize()
}

void updated() {
   log.debug "updated()"
   initialize()
}

void initialize() {
   log.debug "initialize()"
   if (logEnable) {
      log.debug "Debug logging will be automatically disabled in ${debugAutoDisableMinutes} minutes"
      runIn(debugAutoDisableMinutes*60, "debugOff")
   }
}

// Probably won't happen but...
void parse(String description) {
   log.warn("Running unimplemented parse for: '${description}'")
}

/**
 * Parses V2 Hue Bridge device ID out of Hubitat DNI for use with Hue V2 API calls
 * Hubitat DNI is created in format "CCH/AppID/Sensor/HueDeviceIDv2", so just
 * looks for string after last "/" character
 */
String getHueDeviceIdV2() {
   return device.deviceNetworkId.split("/")[-1]
}

/**
 * (for "new"/v2/EventSocket [SSE] API; chimes are not available on V1)
 * Iterates over Hue device state states in Hue API v2 format and does
 * a sendEvent for each relevant attribute; intended to be called when EventSocket data
 * received for device (as an alternative to polling, though could be used with V2 poll)
 */
void createEventsFromMapV2(Map data) {
   if (logEnable == true) log.debug "createEventsFromMapV2($data)"
   String eventName, eventUnit, descriptionText
   def eventValue // could be String or number
   data.each { String key, value ->
      switch (key) {
         case "alarm":
            // likely static data only set during install (or refresh)
            if (value.sound_values) {
               state.alarmSoundValues = value.sound_values
            }
            // likely event/status update
            if (value.status) {
               eventName = "alarm"
               eventValue = value.status.sound == "no_sound" ? "off" : "siren"
               eventUnit = null
               if (device.currentValue(eventName) != eventValue) doSendEvent(eventName, eventValue, eventUnit)
            }
            break
         // Probably not going to use this, but keeping so should be easy to add later if desired:
         case "alert":
            // likely static data only set during install (or refresh)
            if (value.sound_values) {
               state.alertSoundValues = value.sound_values
            }
            // likely event/status update
            if (value.status) {
               // ignoring, only using chime and alarm (for now?)
               if (logEnable) log.debug "skip: alert data $value"
            }
            break
         case "chime":
            // likely static data only set during install (or refresh)
            if (value.sound_values) {
               eventName = "soundEffects"
               Map valueMap = (0..<value.sound_values.size()).collectEntries { index ->
                  [(index): value.sound_values[index]]
               }
               if (!valueMap) valueMap = [:]
               valueMap.remove("no_sound") // not useful in list of sound effects
               eventValue = new groovy.json.JsonBuilder(valueMap).toString()
               if (device.currentValue(eventName) != eventValue) doSendEvent(eventName, eventValue)
            }
            // likely event/status update
            if (value.status) {
               eventName = "status"
               eventValue = value.status.sound == "no_sound" ? "stopped" : "playing"
               eventUnit = null
               if (device.currentValue(eventName) != eventValue) doSendEvent(eventName, eventValue, eventUnit)
            }
            break
         case "mute":
            eventName = "mute"
            if (value.mute == "mute") eventValue = "muted"
            else if (value.mute == "unmute") eventValue = "unmuted"
            else eventValue = "unknown"
            if (device.currentValue(eventName) != eventValue) doSendEvent(eventName, eventValue)
            break
         case "status":
            if (data.type == "zigbee_connectivity") { // not sure if any other types use this key, but just in case
               eventName = "networkStatus"
               if (value == "disconnected" || value == "connectivity_issue") {
                  eventValue = "offline"
               }
               else {
                  eventValue = "online"
               }
               eventUnit = null
               if (device.currentValue(eventName) != eventValue) {
                  doSendEvent(eventName, eventValue, eventUnit)
               }
            }
            break
         default:
            if (logEnable == true) log.debug "not handling: key = $key, value = $value"
      }
   }
}

// Siren capability methods

void both() {
   if (logEnable) log.debug "both()"
   log.warn "Command \"both()\" not supported on Hue chime devices"
}

void off() {
   if (logEnable) log.debug "off()"
   sendBridgeCommandV2(["alarm": ["sound": "no_sound"]])
}

void siren() {
   if (logEnable) log.debug "siren()"
   String soundValue = "siren"
   if (!(soundValue in state.alarmSoundValues)) {
      if (state.alarmSoundValues == null || state.alarmSoundValues == []) {
         if (logEnable) log.debug "No alarm sound values known; trying \"${soundValue}\" as default"
      }
      else {
         if (logEnable) log.debug "\"${soundValue}\" not in known alarm sound values; using first non-\"no_sound\" value"
         soundValue = state.alarmSoundValues.find({ it.key != "no_sound" })?.value
      }
   }
   if (settings.sirenVolume != null && settings.sirenVolume != "101") {
      volume = Integer.parseInt(settings.sirenVolume)
      sendBridgeCommandV2(["alarm": ["sound": soundValue, "volume": ["level": volume]]])
   }
   else {
      sendBridgeCommandV2(["alarm": ["sound": soundValue]])
   }
}

void strobe() {
   if (logEnable) log.debug "strobe()"
   log.warn "Command \"strobe()\" not supported on Hue chime devices"
}

// Chime capability methods

void playSound(Number soundNumber) {
   if (logEnable) log.debug "playSound(Number $soundNumber)"
   Map chimeSounds = device.currentValue("soundEffects") ? new groovy.json.JsonSlurper().parseText(device.currentValue("soundEffects")) : [:]
   String soundName = chimeSounds.get("$soundNumber")
   if (soundName == null) {
      if (logEnable) "No chime sound name found for number $soundNumber; using \"hue_default\" as default"
      soundName = "hue_default"
   }
   if (settings.chimeVolume != null && settings.chimeVolume != "101") {
      Integer volume = Integer.parseInt(settings.chimeVolume)
      sendBridgeCommandV2(["chime": ["sound": soundName, "volume": ["level": volume]]])
   }
   else {
      sendBridgeCommandV2(["chime": ["sound": soundName]])
   }
}

void playSound(String soundNumber) {
   if (logEnable) log.debug "playSound(String $soundNumber)"
   if (!soundNumber.isInteger()) {
      log.warn "playSound() called with non-integer string value: $soundNumber; exiting"
      // TODO: Consider finding by name instead, though is not standard
      return
   }
   playSound(Integer.parseInt(soundNumber))
}

void stop() {
   if (logEnable) log.debug "stop()"
   sendBridgeCommandV2(["chime": ["sound": "no_sound"]]) 
}

// Tone capability methods

void beep() {
   if (logEnable) log.debug "beep()"
   String soundValue = "alert"
   if (!(soundValue in state.alertSoundValues)) {
      if (state.alertSoundValues == null || state.alertSoundValues == []) {
         if (logEnable) log.debug "No alert sound values known; trying \"${soundValue}\" as default"
      }
      else {
         if (logEnable) log.debug "\"${soundValue}\" not in known alert sound values; using first non-\"no_sound\" value"
         soundValue = state.alertSoundValues.find({ it.key != "no_sound" })?.value
      }
   }
   if (settings.beepVolume != null && settings.beepVolume != "101") {
      volume = Integer.parseInt(settings.beepVolume)
      sendBridgeCommandV2(["alert": ["sound": soundValue, "volume": ["level": volume]]])
   }
   else {
      sendBridgeCommandV2(["alert": ["sound": soundValue]])
   }
}

// Other methods

/**
 * Sends HTTP PUT to Bridge using the V2-format map data provided
 * @param commandMap Groovy Map (will be converted to JSON) of Hue V2 API commands to send, e.g., [on: true]
 * @param createHubEvents Will iterate over Bridge command map and do sendEvent for all
 *        affected device attributes (e.g., will send an "on" event for "switch" if ["on": true] in map)
 */
void sendBridgeCommandV2(Map commandMap, Boolean createHubEvents=false) {
   if (logEnable == true) log.debug "sendBridgeCommandV2($commandMap)"
   if (commandMap == null || commandMap == [:]) {
      if (logEnable == true) log.debug "Commands not sent to Bridge because command map null or empty"
      return
   }
   parent.bridgeAsyncPutV2("parseSendCommandResponseV2", this.device, "/resource/speaker/${getHueDeviceIdV2()}",
                           commandMap, createHubEvents ? commandMap : null)
   if (logEnable == true) log.debug "-- Command sent to Bridge! --"
}

/** 
  * Parses response from Bridge (or not) after sendBridgeCommandV2. Can optionally use V1-inspired
  * logic to update device states if `data` map provided.
  * @param resp Async HTTP response object
  * @param data Map of commands sent to Bridge if specified to create events from map (probably won't use for this driver)
  */
void parseSendCommandResponseV2(AsyncResponse resp, Map data) {
   if (logEnable == true) log.debug "parseSendCommandResponseV2(): Response status from Bridge: ${resp.status}"
   if (checkIfValidResponse(resp) && data) {
      if (logEnable == true) log.debug "  Bridge response valid; creating events from data map"
      createEventsFromMapV2(data)
   }
   else {
      if (logEnable == true) log.debug "  Not creating events from map because not specified to do or Bridge response invalid"
   }
}

// ~~~ IMPORTED FROM RMoRobert.CoCoHue_Common_Lib ~~~
// Version 1.0.6
// For use with CoCoHue drivers (not app)

/**
 * 1.0.6 - Remove common bridgeAsyncPutV2() method (now call from parent app instead of driver)
 * 1.0.5 - Add common bridgeAsyncPutV2() method for asyncHttpPut (goal to reduce individual driver code)
 * 1.0.4 - Add common bridgeAsyncGetV2() method asyncHttpGet (goal to reduce individual driver code)
 * 1.0.3 - Add APIV1 and APIV2 "constants"
 * 1.0.2  - HTTP error handling tweaks
 */

void debugOff() {
   log.warn "Disabling debug logging"
   device.updateSetting("logEnable", [value:"false", type:"bool"])
}

/** Performs basic check on data returned from HTTP response to determine if should be
  * parsed as likely Hue Bridge data or not; returns true (if OK) or logs errors/warnings and
  * returns false if not
  * @param resp The async HTTP response object to examine
  */
private Boolean checkIfValidResponse(hubitat.scheduling.AsyncResponse resp) {
   if (logEnable == true) log.debug "Checking if valid HTTP response/data from Bridge..."
   Boolean isOK = true
   if (resp.status < 400) {
      if (resp.json == null) {
         isOK = false
         if (resp.headers == null) log.error "Error: HTTP ${resp.status} when attempting to communicate with Bridge"
         else log.error "No JSON data found in response. ${resp.headers.'Content-Type'} (HTTP ${resp.status})"
         parent.sendBridgeDiscoveryCommandIfSSDPEnabled(true) // maybe IP changed, so attempt rediscovery 
         parent.setBridgeOnlineStatus(false)
      }
      else if (resp.json) {
         if ((resp.json instanceof List) && resp.json.getAt(0).error) {
            // Bridge (not HTTP) error (bad username, bad command formatting, etc.):
            isOK = false
            log.warn "Error from Hue Bridge: ${resp.json[0].error}"
            // Not setting Bridge to offline when light/scene/group devices end up here because could
            // be old/bad ID and don't want to consider Bridge offline just for that (but also won't set
            // to online because wasn't successful attempt)
         }
         // Otherwise: probably OK (not changing anything because isOK = true already)
      }
      else {
         isOK = false
         log.warn("HTTP status code ${resp.status} from Bridge")
         // TODO: Update for mDNS if/when switch:
         if (resp?.status >= 400) parent.sendBridgeDiscoveryCommandIfSSDPEnabled(true) // maybe IP changed, so attempt rediscovery 
         parent.setBridgeOnlineStatus(false)
      }
      if (isOK == true) parent.setBridgeOnlineStatus(true)
   }
   else {
      log.warn "Error communicating with Hue Bridge: HTTP ${resp?.status}"
      isOK = false
   }
   return isOK
}

void doSendEvent(String eventName, eventValue, String eventUnit=null, Boolean forceStateChange=false) {
   //if (logEnable == true) log.debug "doSendEvent($eventName, $eventValue, $eventUnit)"
   String descriptionText = "${device.displayName} ${eventName} is ${eventValue}${eventUnit ?: ''}"
   if (settings.txtEnable == true) log.info(descriptionText)
   if (eventUnit) {
      if (forceStateChange == true) sendEvent(name: eventName, value: eventValue, descriptionText: descriptionText, unit: eventUnit, isStateChange: true) 
      else sendEvent(name: eventName, value: eventValue, descriptionText: descriptionText, unit: eventUnit) 
   } else {
      if (forceStateChange == true) sendEvent(name: eventName, value: eventValue, descriptionText: descriptionText, isStateChange: true) 
      else sendEvent(name: eventName, value: eventValue, descriptionText: descriptionText) 
   }
}

// HTTP methods (might be better to split into separate library if not needed for some?)

/** Performs asynchttpGet() to Bridge using data retrieved from parent app or as passed in
  * @param callbackMethod Callback method
  * @param clipV2Path The Hue V2 API path ('/clip/v2' is automatically prepended), e.g. '/resource' or '/resource/light'
  * @param bridgeData Bridge data from parent getBridgeData() call, or will call this method on parent if null
  * @param data Extra data to pass as optional third (data) parameter to asynchtttpGet() method
  */
void bridgeAsyncGetV2(String callbackMethod, String clipV2Path, Map<String,String> bridgeData = null, Map data = null) {
   if (bridgeData == null) {
      bridgeData = parent.getBridgeData()
   }
   Map params = [
      uri: "https://${bridgeData.ip}",
      path: "/clip/v2${clipV2Path}",
      headers: ["hue-application-key": bridgeData.username],
      contentType: "application/json",
      timeout: 15,
      ignoreSSLIssues: true
   ]
   asynchttpGet(callbackMethod, params, data)
}


// ~~~ IMPORTED FROM RMoRobert.CoCoHue_Constants_Lib ~~~
// Version 1.0.2

// --------------------------------------
// APP AND DRIVER NAMESPACE AND NAMES:
// --------------------------------------
@Field static final String NAMESPACE                  = "RMoRobert"
@Field static final String DRIVER_NAME_BRIDGE         = "CoCoHue Bridge"
@Field static final String DRIVER_NAME_BUTTON         = "CoCoHue Button"
@Field static final String DRIVER_NAME_CHIME          = "CoCoHue Chime"
@Field static final String DRIVER_NAME_CT_BULB        = "CoCoHue CT Bulb"
@Field static final String DRIVER_NAME_DIMMABLE_BULB  = "CoCoHue Dimmable Bulb"
@Field static final String DRIVER_NAME_GROUP          = "CoCoHue Group"
@Field static final String DRIVER_NAME_MOTION         = "CoCoHue Motion Sensor"
@Field static final String DRIVER_NAME_MOTION_AREA    = "CoCoHue Motion Area"
@Field static final String DRIVER_NAME_CONTACT        = "CoCoHue Contact Sensor"
@Field static final String DRIVER_NAME_PLUG           = "CoCoHue Plug"
@Field static final String DRIVER_NAME_RGBW_BULB      = "CoCoHue RGBW Bulb"
@Field static final String DRIVER_NAME_RGB_BULB       = "CoCoHue RGB Bulb"
@Field static final String DRIVER_NAME_SCENE          = "CoCoHue Scene"

// --------------------------------------
// DNI PREFIX for child devices:
// --------------------------------------
@Field static final String DNI_PREFIX = "CCH"

// --------------------------------------
// OTHER:
// --------------------------------------
// Used in app and Bridge driver, may eventually find use in more:
@Field static final String APIV1 = "V1"
@Field static final String APIV2 = "V2"